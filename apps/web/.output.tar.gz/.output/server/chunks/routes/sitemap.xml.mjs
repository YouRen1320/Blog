import { d as defineEventHandler, s as setHeader, u as useRuntimeConfig } from '../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';

function escapeXml(s) {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");
}
const sitemap_xml = defineEventHandler(async (event) => {
  const config = useRuntimeConfig();
  const apiBase = config.public.apiBase;
  const siteUrl = config.public.siteUrl.replace(/\/$/, "");
  const articles = [];
  let page = 1;
  while (true) {
    const resp = await $fetch(`${apiBase}/articles`, {
      query: { page, pageSize: 100 }
    });
    articles.push(...resp.data);
    if (page >= resp.meta.totalPages || resp.data.length === 0) break;
    page += 1;
  }
  const staticUrls = [{ loc: `${siteUrl}/`, changefreq: "weekly", priority: "1.0" }];
  const articleUrls = articles.map((a) => {
    var _a;
    return {
      loc: `${siteUrl}/articles/${a.slug}`,
      lastmod: (_a = a.publishedAt) != null ? _a : void 0,
      changefreq: "monthly",
      priority: "0.8"
    };
  });
  const urls = [...staticUrls, ...articleUrls];
  const xml = `<?xml version="1.0" encoding="UTF-8"?>
<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">
` + urls.map(
    (u) => `  <url>
    <loc>${escapeXml(u.loc)}</loc>
` + ("lastmod" in u && u.lastmod ? `    <lastmod>${escapeXml(u.lastmod)}</lastmod>
` : "") + `    <changefreq>${u.changefreq}</changefreq>
    <priority>${u.priority}</priority>
  </url>`
  ).join("\n") + `
</urlset>
`;
  setHeader(event, "Content-Type", "application/xml; charset=utf-8");
  setHeader(event, "Cache-Control", "public, max-age=3600");
  return xml;
});

export { sitemap_xml as default };
//# sourceMappingURL=sitemap.xml.mjs.map
