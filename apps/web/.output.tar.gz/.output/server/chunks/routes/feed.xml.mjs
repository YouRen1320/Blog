import { d as defineEventHandler, s as setHeader, u as useRuntimeConfig } from '../nitro/nitro.mjs';
import 'node:http';
import 'node:https';
import 'node:events';
import 'node:buffer';
import 'node:fs';
import 'node:path';
import 'node:crypto';
import 'node:url';

function escapeXml(s) {
  return s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;").replace(/"/g, "&quot;").replace(/'/g, "&apos;");
}
function toRfc822(iso) {
  return new Date(iso != null ? iso : Date.now()).toUTCString();
}
const feed_xml = defineEventHandler(async (event) => {
  var _a, _b;
  const config = useRuntimeConfig();
  const apiBase = config.public.apiBase;
  const siteUrl = config.public.siteUrl.replace(/\/$/, "");
  const resp = await $fetch(`${apiBase}/articles`, {
    query: { page: 1, pageSize: 20 }
  });
  const articles = resp.data;
  const lastBuildDate = toRfc822((_b = (_a = articles[0]) == null ? void 0 : _a.publishedAt) != null ? _b : null);
  const channelTitle = "YouRen";
  const channelDesc = "Youren \u7684\u5199\u4F5C:\u535A\u5BA2\u3001\u7B14\u8BB0\u3001AI \u5185\u5BB9\u751F\u4EA7\u5B9E\u9A8C\u3002";
  const items = articles.map(
    (a) => `    <item>
      <title>${escapeXml(a.title)}</title>
      <link>${escapeXml(`${siteUrl}/articles/${a.slug}`)}</link>
      <guid isPermaLink="true">${escapeXml(`${siteUrl}/articles/${a.slug}`)}</guid>
      <pubDate>${toRfc822(a.publishedAt)}</pubDate>
` + (a.summary ? `      <description>${escapeXml(a.summary)}</description>
` : "") + `    </item>`
  ).join("\n");
  const xml = `<?xml version="1.0" encoding="UTF-8"?>
<rss version="2.0" xmlns:atom="http://www.w3.org/2005/Atom">
  <channel>
    <title>${escapeXml(channelTitle)}</title>
    <link>${escapeXml(siteUrl)}</link>
    <atom:link href="${escapeXml(`${siteUrl}/feed.xml`)}" rel="self" type="application/rss+xml" />
    <description>${escapeXml(channelDesc)}</description>
    <language>zh-cn</language>
    <lastBuildDate>${lastBuildDate}</lastBuildDate>
` + items + `
  </channel>
</rss>
`;
  setHeader(event, "Content-Type", "application/rss+xml; charset=utf-8");
  setHeader(event, "Cache-Control", "public, max-age=1800");
  return xml;
});

export { feed_xml as default };
//# sourceMappingURL=feed.xml.mjs.map
